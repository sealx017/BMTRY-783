###############################################################################
# GWAS PIPELINE 
#
# Demonstrates:
#   1. Data alignment
#   2. Sample call-rate QC
#   3. Variant call-rate, MAF, and HWE QC
#   4. LD pruning and ancestry PCA
#   5. Additive SNP association testing
#   6. Population-confounding diagnostics
#   7. Bonferroni/FDR correction, Manhattan/QQ plots, and a regional plot
#
###############################################################################

options(stringsAsFactors = FALSE)

# ---------------------------- 0. Configuration ------------------------------

TRAIT_TYPE <- "quantitative"  # Change to "binary" for logistic regression.
N_PCS <- 1  # One ancestry axis is sufficient for the two-group simulation.
SAMPLE_CALL_RATE_MIN <- 0.95
VARIANT_CALL_RATE_MIN <- 0.95
MAF_MIN <- 0.01
HWE_P_MIN <- 1e-6
LD_WINDOW_BP <- 5e5
LD_R2_MAX <- 0.20
ALPHA <- 0.05

locate_project_dir <- function() {
  args <- commandArgs(trailingOnly = FALSE)
  script_arg <- grep("^--file=", args, value = TRUE)
  if (length(script_arg) > 0L) {
    return(dirname(normalizePath(sub("^--file=", "", script_arg[1]))))
  }
  normalizePath(getwd())
}

PROJECT_DIR <- "/Users/sealso/Research/Teaching/BMTRY_783_2026/Codes/GWAS_teaching_demo" #locate_project_dir()
DATA_DIR <- file.path(PROJECT_DIR, "data")
KEY_DIR <- file.path(PROJECT_DIR, "instructor_keys")
RESULTS_DIR <- file.path(PROJECT_DIR, "results")
dir.create(RESULTS_DIR, showWarnings = FALSE, recursive = TRUE)

# ------------------------------- 1. Import and align genotype, phenotype, and map files ----------------------------------

pheno <- read.csv(file.path(DATA_DIR, "phenotypes.csv"), check.names = FALSE)
map <- read.csv(file.path(DATA_DIR, "variant_map.csv"), check.names = FALSE)
geno_df <- read.csv(gzfile(file.path(DATA_DIR, "genotypes.csv.gz")),
                    check.names = FALSE, na.strings = c("NA", ""))

if (anyDuplicated(pheno$IID)) stop("Phenotype file contains duplicated IIDs.")
if (anyDuplicated(geno_df$IID)) stop("Genotype file contains duplicated IIDs.")
if (!setequal(pheno$IID, geno_df$IID)) stop("Genotype and phenotype IIDs differ.")

# Put phenotypes in exactly the same order as genotype rows.
pheno <- pheno[match(geno_df$IID, pheno$IID), , drop = FALSE]
if (!identical(pheno$IID, geno_df$IID)) stop("IID alignment failed.")

G <- as.matrix(geno_df[, -1, drop = FALSE])
storage.mode(G) <- "numeric"
rownames(G) <- geno_df$IID

if (!identical(colnames(G), map$SNP)) {
  stop("Genotype columns and variant-map SNPs are not identically ordered.")
}

valid_genotype <- is.na(G) | G == 0 | G == 1 | G == 2
if (any(!valid_genotype)) {
  stop("Genotypes must be coded 0, 1, 2, or NA.")
}

cat(sprintf("Loaded %d participants and %d variants.\n", nrow(G), ncol(G)))

# --------------------------- Helper functions -------------------------------

# Hardy-Weinberg chi-square test
hwe_chisq_p <- function(g) {
  g <- g[!is.na(g)]
  if (length(g) < 20L) return(NA_real_)
  counts <- tabulate(as.integer(g) + 1L, nbins = 3L)  # AA, AB, BB
  n <- sum(counts)
  p_alt <- (2 * counts[3] + counts[2]) / (2 * n)
  if (p_alt <= 0 || p_alt >= 1) return(1)
  p_ref <- 1 - p_alt
  expected <- c(n * p_ref^2, 2 * n * p_ref * p_alt, n * p_alt^2)
  statistic <- sum((counts - expected)^2 / expected)
  pchisq(statistic, df = 1, lower.tail = FALSE)
}

# Variant-level QC statistics
variant_statistics <- function(genotypes, hwe_rows = seq_len(nrow(genotypes))) {
  call_rate <- colMeans(!is.na(genotypes))
  allele_frequency <- colMeans(genotypes, na.rm = TRUE) / 2
  maf <- pmin(allele_frequency, 1 - allele_frequency)
  hwe_p <- apply(genotypes[hwe_rows, , drop = FALSE], 2, hwe_chisq_p)
  data.frame(
    SNP = colnames(genotypes),
    call_rate = call_rate,
    ALT_frequency = allele_frequency,
    MAF = maf,
    HWE_P = hwe_p,
    row.names = NULL
  )
}

# Missing value imputation
mean_impute <- function(genotypes) {
  out <- genotypes
  column_means <- colMeans(out, na.rm = TRUE)
  missing <- which(is.na(out), arr.ind = TRUE)
  if (nrow(missing) > 0L) out[missing] <- column_means[missing[, 2]]
  out
}


# LD pruning
ld_prune <- function(genotypes, variant_map, maf, window_bp = 5e6,
                     r2_max = 0.20) {
  eligible <- which(maf >= 0.05 & maf <= 0.50)
  retained <- integer(0)

  for (chr in unique(variant_map$CHR)) {
    chr_indices <- eligible[variant_map$CHR[eligible] == chr]
    chr_indices <- chr_indices[order(variant_map$BP[chr_indices])]
    retained_chr <- integer(0)

    for (j in chr_indices) {
      nearby <- retained_chr[
        abs(variant_map$BP[retained_chr] - variant_map$BP[j]) <= window_bp
      ]
      keep_j <- TRUE
      if (length(nearby) > 0L) {
        r <- suppressWarnings(cor(genotypes[, j],
                                  genotypes[, nearby, drop = FALSE],
                                  use = "pairwise.complete.obs"))
        keep_j <- all(is.na(r) | as.numeric(r)^2 < r2_max)
      }
      if (keep_j) retained_chr <- c(retained_chr, j)
    }
    retained <- c(retained, retained_chr)
  }
  sort(retained)
}

# single-SNP linear GWAS
linear_gwas <- function(y, genotypes, covariates = NULL) {
  g <- mean_impute(genotypes)
  x0 <- if (is.null(covariates)) matrix(1, nrow(g), 1) else
    cbind(Intercept = 1, as.matrix(covariates))
  qrx <- qr(x0)
  y_residual <- qr.resid(qrx, y)
  g_residual <- qr.resid(qrx, g)
  ss_g <- colSums(g_residual^2)
  beta <- as.numeric(crossprod(g_residual, y_residual)) / ss_g
  residual_ss <- sum(y_residual^2) - beta^2 * ss_g
  df <- nrow(g) - qrx$rank - 1L
  se <- sqrt((residual_ss / df) / ss_g)
  t_stat <- beta / se
  p_value <- 2 * pt(abs(t_stat), df = df, lower.tail = FALSE)
  data.frame(BETA = beta, SE = se, STAT = t_stat, P = p_value,
             N = nrow(g))
}

# single-SNP logistic GWAS
logistic_gwas <- function(y, genotypes, covariates = NULL) {
  g <- mean_impute(genotypes)
  x0 <- if (is.null(covariates)) matrix(1, nrow(g), 1) else
    cbind(Intercept = 1, as.matrix(covariates))
  out <- matrix(NA_real_, nrow = ncol(g), ncol = 5,
                dimnames = list(NULL, c("BETA", "SE", "STAT", "P", "N")))

  for (j in seq_len(ncol(g))) {
    x <- cbind(x0, SNP = g[, j])
    fit <- suppressWarnings(glm.fit(x = x, y = y, family = binomial()))
    beta <- unname(tail(fit$coefficients, 1))
    if (!fit$converged || !is.finite(beta)) next
    information <- crossprod(x * sqrt(fit$weights))
    covariance <- tryCatch(solve(information), error = function(e) NULL)
    if (is.null(covariance)) next
    se <- sqrt(tail(diag(covariance), 1))
    z <- beta / se
    out[j, ] <- c(beta, se, z, 2 * pnorm(abs(z), lower.tail = FALSE), nrow(g))
  }
  as.data.frame(out)
}

run_gwas <- function(y, genotypes, covariates, trait_type) {
  if (trait_type == "quantitative") {
    linear_gwas(y, genotypes, covariates)
  } else if (trait_type == "binary") {
    logistic_gwas(y, genotypes, covariates)
  } else {
    stop("TRAIT_TYPE must be 'quantitative' or 'binary'.")
  }
}

# genomic lambda
genomic_lambda <- function(p_values) {
  p_values <- p_values[is.finite(p_values) & p_values > 0 & p_values <= 1]
  median(qchisq(p_values, df = 1, lower.tail = FALSE)) /
    qchisq(0.5, df = 1, lower.tail = FALSE)
}

# ------------------------------ 2. Sample QC -------------------------------

sample_qc <- data.frame(
  IID = rownames(G),
  call_rate = rowMeans(!is.na(G)),
  low_call_rate = FALSE,
  duplicate = FALSE,
  removal_reason = "pass"
)
sample_qc$low_call_rate <- sample_qc$call_rate < SAMPLE_CALL_RATE_MIN
sample_qc$removal_reason[sample_qc$low_call_rate] <- "low call rate"

cat(sprintf("Removing %d participants with call rate < %.2f.\n",
            sum(sample_qc$low_call_rate), SAMPLE_CALL_RATE_MIN))

keep_sample <- !sample_qc$low_call_rate
G <- G[keep_sample, , drop = FALSE]
pheno <- pheno[keep_sample, , drop = FALSE]

write.csv(sample_qc, file.path(RESULTS_DIR, "sample_qc.csv"), row.names = FALSE)

# ----------------------------- 3. Variant QC -------------------------------

# For a binary trait, HWE is conventionally assessed among controls.
hwe_rows <- if (TRAIT_TYPE == "binary") which(pheno$case_status == 0) else
  seq_len(nrow(pheno))
variant_qc <- variant_statistics(G, hwe_rows)

variant_qc$removal_reason <- "pass"
variant_qc$removal_reason[variant_qc$call_rate < VARIANT_CALL_RATE_MIN] <-
  "low call rate"
maf_fail <- variant_qc$call_rate >= VARIANT_CALL_RATE_MIN &
  (!is.finite(variant_qc$MAF) | variant_qc$MAF < MAF_MIN)
variant_qc$removal_reason[maf_fail] <- "low MAF"
hwe_fail <- variant_qc$call_rate >= VARIANT_CALL_RATE_MIN &
  is.finite(variant_qc$MAF) & variant_qc$MAF >= MAF_MIN &
  (is.na(variant_qc$HWE_P) | variant_qc$HWE_P < HWE_P_MIN)
variant_qc$removal_reason[hwe_fail] <- "HWE failure"

keep_variant <- variant_qc$removal_reason == "pass"
cat(sprintf("Variants removed: call rate = %d, MAF = %d, HWE = %d.\n",
            sum(variant_qc$removal_reason == "low call rate"),
            sum(variant_qc$removal_reason == "low MAF"),
            sum(variant_qc$removal_reason == "HWE failure")))

write.csv(variant_qc, file.path(RESULTS_DIR, "variant_qc.csv"), row.names = FALSE)
G <- G[, keep_variant, drop = FALSE]
map <- map[keep_variant, , drop = FALSE]
variant_qc_pass <- variant_qc[keep_variant, , drop = FALSE]
stopifnot(identical(colnames(G), map$SNP))
cat(sprintf("Post-QC dataset: %d participants and %d variants.\n",
            nrow(G), ncol(G)))

# ----------------------- 4. LD pruning and PCA -----------------------------

pruned_index <- ld_prune(G, map, variant_qc_pass$MAF,
                         LD_WINDOW_BP, LD_R2_MAX)
G_pca <- mean_impute(G[, pruned_index, drop = FALSE])
af_pca <- colMeans(G_pca) / 2
sd_hwe <- sqrt(2 * af_pca * (1 - af_pca))
valid_sd <- is.finite(sd_hwe) & sd_hwe > 0
G_pca <- G_pca[, valid_sd, drop = FALSE]
af_pca <- af_pca[valid_sd]
sd_hwe <- sd_hwe[valid_sd]

Z <- sweep(G_pca, 2, 2 * af_pca, FUN = "-")
Z <- sweep(Z, 2, sd_hwe, FUN = "/")
pca <- prcomp(Z, center = FALSE, scale. = FALSE,
              rank. = max(10L, N_PCS))
pcs_for_output <- pca$x[, seq_len(max(10L, N_PCS)), drop = FALSE]
colnames(pcs_for_output) <- paste0("PC", seq_len(ncol(pcs_for_output)))
pcs_for_model <- pcs_for_output[, seq_len(N_PCS), drop = FALSE]

cat(sprintf("PCA used %d approximately LD-pruned common variants.\n",
            ncol(G_pca)))

pca_scores <- cbind(IID = rownames(G), as.data.frame(pcs_for_output),
                    self_report_group = pheno$self_report_group)
write.csv(pca_scores, file.path(RESULTS_DIR, "pca_scores.csv"), row.names = FALSE)

group_colors <- c(Group_A = "#2166AC", Group_B = "#B2182B")
png(file.path(RESULTS_DIR, "01_pca.png"), width = 1600, height = 1200,
    res = 180)
plot(pcs_for_output[, 1], pcs_for_output[, 2], pch = 19,
     col = adjustcolor(group_colors[pheno$self_report_group], alpha.f = 0.75),
     xlab = "PC1", ylab = "PC2", main = "Genetic ancestry structure")
legend("topright", legend = names(group_colors), col = group_colors,
       pch = 19, bty = "n")
dev.off()

# -------------------------- 5. Association tests ---------------------------

section("5. Genome-wide association tests")

if (TRAIT_TYPE == "quantitative") {
  outcome <- pheno$quantitative_trait
  outcome_name <- "quantitative_trait"
} else if (TRAIT_TYPE == "binary") {
  outcome <- pheno$case_status
  outcome_name <- "case_status"
  cat(sprintf("Cases = %d; controls = %d.\n", sum(outcome == 1), sum(outcome == 0)))
} else {
  stop("TRAIT_TYPE must be 'quantitative' or 'binary'.")
}

# Both models include measured covariates. Their only difference is ancestry PCs.
base_covariates <- model.matrix(~ scale(age) + sex + batch, data = pheno)[, -1,
                                                                         drop = FALSE]
pc_adjusted_covariates <- cbind(base_covariates, pcs_for_model)

cat("Running covariate-adjusted GWAS without ancestry PCs...\n")
fit_no_pc <- run_gwas(outcome, G, base_covariates, TRAIT_TYPE)
cat("Running covariate- and PC-adjusted GWAS...\n")
fit_with_pc <- run_gwas(outcome, G, pc_adjusted_covariates, TRAIT_TYPE)

results <- cbind(
  map,
  variant_qc_pass[, c("call_rate", "ALT_frequency", "MAF", "HWE_P")],
  BETA_NO_PC = fit_no_pc$BETA,
  SE_NO_PC = fit_no_pc$SE,
  P_NO_PC = fit_no_pc$P,
  BETA_PC = fit_with_pc$BETA,
  SE_PC = fit_with_pc$SE,
  P_PC = fit_with_pc$P
)
results$BONFERRONI_PASS <- results$P_PC < ALPHA / nrow(results)
results$FDR <- p.adjust(results$P_PC, method = "BH")
results$FDR_PASS <- results$FDR < 0.05

truth_path <- file.path(KEY_DIR, "causal_variants.csv")
if (file.exists(truth_path)) {
  truth <- read.csv(truth_path)
  results$KNOWN_CAUSAL <- results$SNP %in% truth$SNP
} else {
  results$KNOWN_CAUSAL <- NA
}

lambda_no_pc <- genomic_lambda(results$P_NO_PC)
lambda_with_pc <- genomic_lambda(results$P_PC)
bonferroni_threshold <- ALPHA / nrow(results)

cat(sprintf("Genomic inflation lambda: %.3f without PCs; %.3f with PCs.\n",
            lambda_no_pc, lambda_with_pc))
cat(sprintf("Bonferroni threshold: %.3g (%d tests).\n",
            bonferroni_threshold, nrow(results)))

result_file <- file.path(RESULTS_DIR,
                         paste0("gwas_results_", TRAIT_TYPE, ".csv"))
write.csv(results, result_file, row.names = FALSE)

top_hits <- results[order(results$P_PC), ]
write.csv(head(top_hits, 25),
          file.path(RESULTS_DIR, paste0("top_hits_", TRAIT_TYPE, ".csv")),
          row.names = FALSE)

# ------------------------------- 6. Plots ----------------------------------

section("6. Diagnostic and association plots")

qq_coordinates <- function(p) {
  p <- sort(p[is.finite(p) & p > 0 & p <= 1])
  data.frame(expected = -log10(ppoints(length(p))), observed = -log10(p))
}

qq_no_pc <- qq_coordinates(results$P_NO_PC)
qq_with_pc <- qq_coordinates(results$P_PC)
qq_limit <- max(c(qq_no_pc$expected, qq_no_pc$observed,
                  qq_with_pc$observed), finite = TRUE)

png(file.path(RESULTS_DIR, "02_qq_plot.png"), width = 1600, height = 1200,
    res = 180)
plot(qq_no_pc$expected, qq_no_pc$observed, pch = 19, cex = 0.6,
     col = adjustcolor("#D73027", alpha.f = 0.55),
     xlim = c(0, qq_limit), ylim = c(0, qq_limit),
     xlab = expression(Expected~~-log[10](italic(P))),
     ylab = expression(Observed~~-log[10](italic(P))),
     main = "QQ plot: population structure inflates association statistics")
points(qq_with_pc$expected, qq_with_pc$observed, pch = 19, cex = 0.6,
       col = adjustcolor("#2166AC", alpha.f = 0.65))
abline(0, 1, lty = 2, col = "gray35")
legend("topleft",
       legend = c(sprintf("No PCs (lambda = %.2f)", lambda_no_pc),
                  sprintf("With PCs (lambda = %.2f)", lambda_with_pc)),
       col = c("#D73027", "#2166AC"), pch = 19, bty = "n")
dev.off()

make_manhattan_data <- function(df) {
  df <- df[order(df$CHR, df$BP), ]
  chromosome_max <- tapply(df$BP, df$CHR, max)
  chromosome_order <- as.numeric(names(chromosome_max))
  offsets <- c(0, cumsum(as.numeric(chromosome_max))[-length(chromosome_max)])
  names(offsets) <- chromosome_order
  df$BP_cumulative <- df$BP + offsets[as.character(df$CHR)]
  axis_locations <- tapply(df$BP_cumulative, df$CHR,
                           function(x) (min(x) + max(x)) / 2)
  list(data = df, axis = axis_locations)
}

manhattan <- make_manhattan_data(results)
md <- manhattan$data
chromosome_colors <- rep(c("#2166AC", "#67A9CF"), 22)

png(file.path(RESULTS_DIR, "03_manhattan_pc_adjusted.png"),
    width = 2200, height = 1100, res = 180)
plot(md$BP_cumulative, -log10(md$P_PC), pch = 20, cex = 0.65,
     col = chromosome_colors[md$CHR], xaxt = "n",
     xlab = "Chromosome", ylab = expression(-log[10](italic(P))),
     main = paste("PC-adjusted GWAS:", outcome_name))
axis(1, at = manhattan$axis, labels = names(manhattan$axis), cex.axis = 0.75)
abline(h = -log10(bonferroni_threshold), col = "#B2182B", lty = 2, lwd = 1.5)
if (any(md$KNOWN_CAUSAL %in% TRUE)) {
  causal_rows <- which(md$KNOWN_CAUSAL %in% TRUE)
  points(md$BP_cumulative[causal_rows], -log10(md$P_PC[causal_rows]),
         pch = 21, cex = 1.25, lwd = 1.4, bg = "#FFD92F", col = "black")
  text(md$BP_cumulative[causal_rows], -log10(md$P_PC[causal_rows]),
       labels = md$SNP[causal_rows], pos = 3, cex = 0.65)
}
dev.off()

png(file.path(RESULTS_DIR, "04_pvalue_change_after_pc_adjustment.png"),
    width = 1500, height = 1300, res = 180)
plot(-log10(results$P_NO_PC), -log10(results$P_PC), pch = 19, cex = 0.65,
     col = adjustcolor("gray25", alpha.f = 0.45),
     xlab = expression(-log[10](italic(P))~~without~~PCs),
     ylab = expression(-log[10](italic(P))~~with~~PCs),
     main = "PC adjustment removes ancestry-confounded signals")
abline(0, 1, lty = 2, col = "#B2182B")
if (any(results$KNOWN_CAUSAL %in% TRUE)) {
  causal_rows <- which(results$KNOWN_CAUSAL %in% TRUE)
  points(-log10(results$P_NO_PC[causal_rows]),
         -log10(results$P_PC[causal_rows]), pch = 21, cex = 1.25,
         bg = "#FFD92F", col = "black")
}
dev.off()

# Regional plot centered on the strongest PC-adjusted SNP.
lead_index <- which.min(results$P_PC)
lead_chr <- results$CHR[lead_index]
lead_bp <- results$BP[lead_index]
region_index <- which(results$CHR == lead_chr &
                        abs(results$BP - lead_bp) <= 5e6)
lead_g <- G[, lead_index]
region_r2 <- vapply(region_index, function(j) {
  r <- suppressWarnings(cor(lead_g, G[, j], use = "pairwise.complete.obs"))
  ifelse(is.finite(r), r^2, NA_real_)
}, numeric(1))
ld_color <- cut(region_r2, breaks = c(-Inf, 0.2, 0.5, 0.8, Inf),
                labels = c("#4575B4", "#91BFDB", "#FC8D59", "#D73027"))

png(file.path(RESULTS_DIR, "05_regional_plot.png"), width = 1600,
    height = 1200, res = 180)
plot(results$BP[region_index] / 1e6, -log10(results$P_PC[region_index]),
     pch = 19, cex = 0.9, col = as.character(ld_color),
     xlab = paste0("Position on chromosome ", lead_chr, " (Mb)"),
     ylab = expression(-log[10](italic(P))),
     main = paste("Regional association around", results$SNP[lead_index]))
points(lead_bp / 1e6, -log10(results$P_PC[lead_index]), pch = 23,
       cex = 1.6, bg = "#FFD92F", col = "black")
legend("topright", legend = c("r2 < 0.2", "0.2-0.5", "0.5-0.8", "r2 >= 0.8"),
       col = c("#4575B4", "#91BFDB", "#FC8D59", "#D73027"),
       pch = 19, bty = "n", title = "LD with lead SNP")
dev.off()

# ------------------------------ 7. Summary ---------------------------------

section("7. Save and summarize")

summary_lines <- c(
  "GWAS teaching demonstration summary",
  paste0("Trait type: ", TRAIT_TYPE),
  sprintf("Starting sample size: %d", nrow(geno_df)),
  sprintf("Post-QC sample size: %d", nrow(G)),
  sprintf("Starting variants: %d", nrow(map) + sum(!keep_variant)),
  sprintf("Post-QC variants: %d", ncol(G)),
  sprintf("Genomic lambda without ancestry PCs: %.3f", lambda_no_pc),
  sprintf("Genomic lambda with ancestry PCs: %.3f", lambda_with_pc),
  sprintf("Bonferroni threshold: %.6g", bonferroni_threshold),
  sprintf("Bonferroni-significant variants: %d", sum(results$BONFERRONI_PASS,
                                                      na.rm = TRUE)),
  sprintf("FDR-significant variants: %d", sum(results$FDR_PASS, na.rm = TRUE)),
  "",
  "Top five PC-adjusted associations:",
  paste(capture.output(print(
    head(top_hits[, c("SNP", "CHR", "BP", "BETA_PC", "SE_PC", "P_PC",
                      "BONFERRONI_PASS", "KNOWN_CAUSAL")], 5),
    row.names = FALSE, digits = 4
  )), collapse = "\n")
)

writeLines(summary_lines,
           file.path(RESULTS_DIR, paste0("analysis_summary_", TRAIT_TYPE, ".txt")))
cat(paste(summary_lines, collapse = "\n"), "\n")
cat("\nAll outputs were written to:\n", normalizePath(RESULTS_DIR), "\n")
